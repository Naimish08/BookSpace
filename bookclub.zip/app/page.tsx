import Component from "../bookspace-app"

export default function Page() {
  return <Component />
}
