import type React from "react"
import type { Metadata } from "next"
import { Inter, Dancing_Script, Playfair_Display, Poppins } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })
const dancingScript = Dancing_Script({
  subsets: ["latin"],
  variable: "--font-dancing-script",
})
const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
})
const poppins = Poppins({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-poppins",
})

export const metadata: Metadata = {
  title: "BookSpace",
  description: "Book club and reading tracking platform",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} ${dancingScript.variable} ${playfair.variable} ${poppins.variable}`}>
        {children}
      </body>
    </html>
  )
}
