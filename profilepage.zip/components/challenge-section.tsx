import { Mail } from "lucide-react"

export default function ChallengeSection() {
  return (
    <section className="py-8">
      <div className="max-w-6xl mx-auto px-4">
        <div className="relative bg-gradient-to-br from-[#391D63] to-[#6e3eb2] rounded-3xl h-96 overflow-hidden flex items-center justify-center text-white text-center">
          <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-48 h-48 bg-[#6e3eb2] bg-opacity-30 rounded-full flex items-center justify-center text-5xl">
            📚✨
          </div>
          <div className="absolute top-4 right-4 w-36 h-28 bg-[#6e3eb2] rounded-full flex items-center justify-center text-3xl">
            📖📚
          </div>
          <div className="relative z-10">
            <h2 className="text-4xl md:text-5xl font-serif mb-4">Your Challenge for today is here!</h2>
            <div className="text-6xl my-4">
              <Mail className="w-16 h-16 mx-auto" />
            </div>
            <p className="text-xl italic mb-2">Sign Up to open the Challenge</p>
            <p className="text-sm text-purple-200">letter opening animation</p>
          </div>
        </div>
      </div>
    </section>
  )
}
