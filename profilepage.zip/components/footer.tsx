import { Instagram, Twitter, Phone, Mail } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-[#a678d1] text-white py-8 mt-12">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div>
            <h3 className="font-bold text-lg mb-2">BOOKSPACE</h3>
          </div>
          <div>
            <h4 className="font-semibold mb-2">Address</h4>
            <p className="text-sm mb-1">Devdevesh | Sensing College of Engineering,</p>
            <p className="text-sm">Vile Parle West, Mumbai-400056</p>
          </div>
          <div>
            <h4 className="font-semibold mb-2">Contact</h4>
            <p className="text-sm mb-1">bookspace@gmail.com</p>
            <p className="text-sm">+91 98765 43210</p>
          </div>
          <div>
            <h4 className="font-semibold mb-2">Follow us</h4>
            <div className="flex gap-2">
              <Instagram className="w-5 h-5" />
              <Twitter className="w-5 h-5" />
              <Phone className="w-5 h-5" />
              <Mail className="w-5 h-5" />
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
