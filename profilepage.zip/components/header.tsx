import { User } from "lucide-react"

export default function Header() {
  return (
    <header className="bg-[#fcefdc] border-b-2 border-gray-200 py-4">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold font-serif">
            Book<span className="text-[#965bcd]">Space</span>
          </h1>
          <nav className="hidden md:flex gap-6 items-center">
            <a href="#" className="font-semibold hover:text-[#965bcd] transition-colors">
              About Us
            </a>
            <a href="#" className="font-semibold hover:text-[#965bcd] transition-colors">
              Home
            </a>
            <a href="#" className="font-semibold hover:text-[#965bcd] transition-colors">
              Events
            </a>
            <a href="#" className="font-semibold hover:text-[#965bcd] transition-colors">
              Club
            </a>
            <a href="#" className="font-semibold hover:text-[#965bcd] transition-colors">
              Join Us
            </a>
            <a href="#" className="font-semibold hover:text-[#965bcd] transition-colors">
              Writers
            </a>
            <User className="w-6 h-6" />
          </nav>
        </div>
      </div>
    </header>
  )
}
