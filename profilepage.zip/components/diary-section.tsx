import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export default function DiarySection() {
  return (
    <section className="py-8">
      <div className="max-w-6xl mx-auto px-4">
        <div className="bg-[#824e74] text-white rounded-xl overflow-hidden">
          <div className="p-6 border-b border-white border-opacity-20">
            <h3 className="text-xl font-semibold text-center">Book Diary</h3>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input placeholder="Name of Book" className="bg-[#fbeff8] text-black border-none" />
                <Button
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:bg-opacity-10 bg-transparent"
                >
                  + add a book
                </Button>
              </div>

              <Input placeholder="Author" className="bg-[#fbeff8] text-black border-none" />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input placeholder="Genre" className="bg-[#fbeff8] text-black border-none" />
                <div>
                  <div className="flex gap-2 mb-2">
                    <Button size="sm" className="bg-[#965bcd] hover:bg-[#7c3aed]">
                      pie chart
                    </Button>
                    <Button size="sm" className="bg-[#965bcd] hover:bg-[#7c3aed]">
                      color to genre label
                    </Button>
                  </div>
                  <p className="text-xs">Genres I want to explore:</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input placeholder="Start date" className="bg-[#fbeff8] text-black border-none" />
                <Input placeholder="End date" className="bg-[#fbeff8] text-black border-none" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Button size="sm" className="bg-[#965bcd] hover:bg-[#7c3aed] mb-2 block">
                    my wishlist
                  </Button>
                  <Button size="sm" className="bg-[#965bcd] hover:bg-[#7c3aed] mb-2 block">
                    reading goals
                  </Button>
                  <p className="text-xs">updates on profile</p>
                </div>
                <div></div>
              </div>

              <Textarea
                placeholder="How much I liked this book"
                className="bg-[#fbeff8] text-black border-none min-h-16"
              />
              <Textarea placeholder="I think this book..." className="bg-[#fbeff8] text-black border-none min-h-16" />

              <div className="flex gap-4">
                <Button className="bg-[#965bcd] hover:bg-[#7c3aed]">SAVE</Button>
                <Button className="bg-[#965bcd] hover:bg-[#7c3aed]">PUBLISH</Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
