"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { BookOpen, ChevronLeft, ChevronRight } from "lucide-react"

export default function RecapSection() {
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth())
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear())

  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ]

  const getDaysInMonth = (month: number, year: number) => {
    return new Date(year, month + 1, 0).getDate()
  }

  const getFirstDayOfMonth = (month: number, year: number) => {
    const firstDay = new Date(year, month, 1).getDay()
    return firstDay === 0 ? 6 : firstDay - 1 // Convert Sunday (0) to 6, Monday (1) to 0
  }

  const previousMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11)
      setCurrentYear(currentYear - 1)
    } else {
      setCurrentMonth(currentMonth - 1)
    }
  }

  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0)
      setCurrentYear(currentYear + 1)
    } else {
      setCurrentMonth(currentMonth + 1)
    }
  }

  const renderCalendar = () => {
    const daysInMonth = getDaysInMonth(currentMonth, currentYear)
    const firstDay = getFirstDayOfMonth(currentMonth, currentYear)
    const days = []

    // Empty cells for days before first day
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-8"></div>)
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(
        <div
          key={day}
          className="h-8 flex items-center justify-center rounded cursor-pointer hover:bg-white hover:bg-opacity-20 transition-colors"
        >
          {day}
        </div>,
      )
    }

    return days
  }

  return (
    <section className="py-8">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Monthly Reading Recap */}
          <div className="bg-[#7b4794] text-white rounded-xl overflow-hidden">
            <div className="p-6 border-b border-white border-opacity-20">
              <div className="flex items-center gap-2">
                <BookOpen className="w-6 h-6" />
                <h3 className="text-xl font-semibold">Monthly Reading Recap</h3>
              </div>
            </div>
            <div className="p-6">
              <p className="text-sm mb-4">Books Read This Month</p>

              <div className="flex gap-3 overflow-x-auto mb-4">
                {[1, 2, 3, 4].map((book) => (
                  <div key={book} className="flex-shrink-0 text-center">
                    <div className="w-20 h-32 bg-[#5e2e91] rounded-lg flex items-center justify-center text-2xl mb-2">
                      📖
                    </div>
                    <div className="flex justify-center gap-0.5">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <span key={star} className="text-yellow-400 text-xs">
                          ★
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <div className="space-y-2 mb-4">
                <div className="bg-[#d6b8ff] text-black px-3 py-1 rounded-full text-sm w-fit">Total Books Read: 5</div>
                <div className="bg-[#d6b8ff] text-black px-3 py-1 rounded-full text-sm w-fit">Books Reviewed: 3</div>
                <div className="bg-[#d6b8ff] text-black px-3 py-1 rounded-full text-sm w-fit">Streak: 10 days</div>
              </div>

              <div className="text-center">
                <p className="text-sm mb-2">Highest Rated Book of the Month</p>
                <div className="relative w-20 h-32 bg-[#5e2e91] rounded-lg flex items-center justify-center text-2xl mx-auto">
                  📖<div className="absolute -top-2 -right-2 text-2xl">👑</div>
                </div>
              </div>
            </div>
          </div>

          {/* Calendar */}
          <div className="bg-[#824e74] text-white rounded-xl overflow-hidden">
            <div className="p-6 border-b border-white border-opacity-20">
              <div className="flex justify-between items-center">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={previousMonth}
                  className="text-white hover:bg-white hover:bg-opacity-20"
                >
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <h3 className="text-xl font-semibold">
                  {monthNames[currentMonth]} {currentYear}
                </h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={nextMonth}
                  className="text-white hover:bg-white hover:bg-opacity-20"
                >
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-7 gap-2 text-center text-sm mb-4">
                {["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"].map((day) => (
                  <div key={day}>{day}</div>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-2 text-center text-sm">{renderCalendar()}</div>
              <p className="text-center mt-4 text-sm">
                <span className="text-lg mr-2">📅</span>
                reading streak calendar
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
