export default function LibrarySection() {
  const shelves = [
    { title: "currently reading", books: 2 },
    { title: "lined up next", books: 4 },
    { title: "finished reading", books: 4 },
    { title: "reviewed", books: 3 },
  ]

  return (
    <section className="py-8">
      <div className="max-w-6xl mx-auto px-4">
        <div className="bg-white rounded-xl overflow-hidden">
          <div className="p-6">
            <h2 className="text-3xl font-bold text-center text-[#824e74] mb-8">My Library</h2>

            {shelves.map((shelf, index) => (
              <div key={index} className="relative mb-8">
                <div className="absolute inset-0 flex">
                  <div className="w-32 md:w-72 h-48 bg-gradient-to-br from-purple-100 to-purple-200 rounded-l-lg flex items-center justify-center text-2xl md:text-4xl">
                    📚📖📗
                  </div>
                  <div className="flex-1 bg-gradient-to-r from-yellow-100 to-orange-50"></div>
                  <div className="w-32 md:w-72 h-48 bg-gradient-to-bl from-purple-100 to-purple-200 rounded-r-lg flex items-center justify-center text-2xl md:text-4xl">
                    📚📖📗
                  </div>
                </div>
                <div className="relative z-10 bg-white bg-opacity-95 mx-8 md:mx-32 p-6 rounded-lg shadow-lg">
                  <h3 className="text-[#824e74] font-semibold mb-4 capitalize">{shelf.title}</h3>
                  <div className="flex gap-4 justify-center mb-4">
                    {Array.from({ length: shelf.books }).map((_, bookIndex) => (
                      <div key={bookIndex} className="w-16 h-24 bg-[#5e2e91] rounded shadow-md"></div>
                    ))}
                  </div>
                  <div className="w-full h-1 bg-[#824e74] rounded"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
