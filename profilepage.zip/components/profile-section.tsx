import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { BookOpen } from "lucide-react"

export default function ProfileSection() {
  return (
    <section className="py-8">
      <div className="max-w-6xl mx-auto px-4">
        <div className="bg-gradient-to-b from-[#A27B94] to-[#8B5A7F] rounded-xl text-white overflow-hidden">
          <div className="p-6 border-b border-white border-opacity-20 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <BookOpen className="w-6 h-6" />
              <h3 className="text-xl font-semibold">My BookSpace Profile</h3>
            </div>
            <Button variant="secondary" size="sm" className="rounded-full">
              Edit
            </Button>
          </div>
          <div className="p-6">
            <div className="text-center text-2xl font-semibold mb-6">readinglovesme</div>

            <div className="flex gap-6 items-start mb-6">
              <div className="w-32 h-32 bg-white rounded-full flex-shrink-0"></div>
              <div className="flex-1 mt-4">
                <div className="space-y-3">
                  <div className="h-1 bg-black bg-opacity-40 rounded w-4/5"></div>
                  <div className="h-1 bg-black bg-opacity-40 rounded w-3/5"></div>
                  <div className="h-1 bg-black bg-opacity-40 rounded w-4/5"></div>
                </div>
                <p className="text-center text-sm text-purple-200 mt-4">(bio)</p>
              </div>
            </div>

            <div className="mb-6">
              <h4 className="text-xl mb-4">Realname</h4>
              <div className="flex items-center gap-4 flex-wrap">
                <Button variant="secondary" size="sm" className="rounded-full">
                  CONNECT
                </Button>
                <span>readinglovesme@gmail.com</span>
              </div>
            </div>

            <div className="mb-6">
              <h4 className="text-lg mb-3">genres</h4>
              <div className="flex gap-3 flex-wrap">
                {["genre", "genre", "genre", "genre"].map((genre, index) => (
                  <div key={index} className="bg-[#5A3D6B] px-6 py-2 rounded-full text-sm">
                    {genre}
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="space-y-2">
                <label className="block">current read</label>
                <div className="relative">
                  <Input className="rounded-full bg-[#fbeff8] text-black pr-12" />
                  <div className="absolute right-3 top-1/2 transform -translate-y-1/2 w-6 h-6 bg-[#5A3D6B] rounded-full flex items-center justify-center text-xs">
                    📖
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <label className="block">gift me a book</label>
                <div className="relative">
                  <Input placeholder="WISHLISTED" className="rounded-full bg-[#fbeff8] text-black pr-12" />
                  <div className="absolute right-3 top-1/2 transform -translate-y-1/2 w-6 h-6 bg-[#5A3D6B] rounded-full flex items-center justify-center text-xs">
                    📖
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-6 text-center mb-6">
              {[
                { label: "views", value: "0" },
                { label: "connections", value: "0" },
                { label: "searches", value: "0" },
              ].map((stat, index) => (
                <div key={index} className="space-y-2">
                  <div>{stat.label}</div>
                  <div className="bg-white text-black rounded-full h-8 flex items-center justify-center text-sm">
                    {stat.value}
                  </div>
                </div>
              ))}
            </div>

            <p className="text-sm italic text-purple-200 leading-relaxed">
              what is connection? when you slide the connect button to the right, it indicates you are interested in
              their profile
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
