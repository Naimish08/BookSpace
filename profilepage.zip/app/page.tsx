import Header from "@/components/header"
import ChallengeSection from "@/components/challenge-section"
import ProfileSection from "@/components/profile-section"
import RecapSection from "@/components/recap-section"
import DiarySection from "@/components/diary-section"
import LibrarySection from "@/components/library-section"
import Footer from "@/components/footer"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-[#fcefdc] text-[#2d1e2f]">
      <Header />
      <ChallengeSection />
      <ProfileSection />
      <RecapSection />
      <DiarySection />
      <LibrarySection />
      <Footer />
    </div>
  )
}
